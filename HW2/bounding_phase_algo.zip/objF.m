
function fun = objF(x)

fun = 2*(x-3)^2 + exp(0.5*x*x);

end